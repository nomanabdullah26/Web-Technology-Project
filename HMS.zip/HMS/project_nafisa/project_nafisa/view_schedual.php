<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Schedules</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Available Doctor Schedules</h1>
    <div id="doctor-list"></div>

    <script src="view_schedules.js"></script>
</body>
</html>
